package NextLevel.treeSearchPlanners.twoPlayer.TPOLITSPlanner;

import java.util.Random;

import NextLevel.StateEvaluator;
import NextLevel.StateHandler;
import NextLevel.moveController.AgentMoveController;
import NextLevel.treeSearchPlanners.TreeNode;
import NextLevel.treeSearchPlanners.TreeSearchMovePlanner;
import NextLevel.twoPlayer.TPGameKnowledge;
import NextLevel.twoPlayer.TPGameKnowledgeExplorer;
import NextLevel.twoPlayer.TPStateHandler;
import core.game.StateObservation;

public class TPOLITSMovePlanner extends TreeSearchMovePlanner
{
	// Real types of fields
	// protected TPStateHandler stateHandler;
	// protected StateEvaluator stateEvaluator;
	// protected TPGameKnowledge gameKnowledge;
	// protected TPGameKnowledgeExplorer gameKnowledgeExplorer; 
	// protected AgentMoveController agentMoveController;
	// protected TPOLMCTSTreeNode rootNode;
	// protected BasicTPState rootState;
	// protected StateObservationMulti rootStateObs;
	// protected TPOLMCTSMoveController treeSearchMoveController; 
	
	// Algorithm parameters
	
	protected int remainingLimit;
	
	public TPOLITSMovePlanner(TPStateHandler stateHandler, StateEvaluator stateEvaluator, TPGameKnowledge gameKnowledge,
			TPGameKnowledgeExplorer gameKnowledgeExplorer, AgentMoveController agentMoveController, 
			TPOLITSMoveController treeSearchMoveController)
	{
		this.stateHandler = stateHandler;
		this.stateEvaluator = stateEvaluator;
		this.gameKnowledge = gameKnowledge;
		this.gameKnowledgeExplorer = gameKnowledgeExplorer;
		this.agentMoveController = agentMoveController;
		this.treeSearchMoveController = treeSearchMoveController;
		
		this.randomGenerator = new Random();
		this.treeSearchMoveController.setRandomGenerator(randomGenerator);
	}
	
	public void setParameters(int remainingLimit)
	{
		this.remainingLimit = remainingLimit;
	}
	
	protected void initialize()
	{
		this.rootNode = new TPOLITSTreeNode(gameKnowledge.getNumOfPlayerActions());
	}
	
	protected boolean isTreePolicyFinished(TreeNode currentNode, StateObservation stateObs, boolean expand)
	{
		return (stateObs.isGameOver() || expand);
	}
		
	protected boolean isRolloutFinished(StateObservation rollerState, int depth)
	{
		if (rollerState.isGameOver()) // end of game
			return true;

		return false;
	}
	
	protected void updateNode(TreeNode node, double delta)
	{
		node.numVisits++;
        node.totalValue += delta;
	}
}
