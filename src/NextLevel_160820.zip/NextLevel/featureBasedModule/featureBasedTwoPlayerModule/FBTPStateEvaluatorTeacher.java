package NextLevel.featureBasedModule.featureBasedTwoPlayerModule;

import NextLevel.StateEvaluatorTeacher;

public class FBTPStateEvaluatorTeacher extends StateEvaluatorTeacher
{
	// Real types of fields
	// private FBTPStateEvaluator stateEvaluator;
	// private FBTPGameKnowledge gameKnowledge;
	
	public FBTPStateEvaluatorTeacher(FBTPStateEvaluator stateEvaluator, FBTPGameKnowledge gameKnowledge)
	{
		this.stateEvaluator = stateEvaluator;
		this.gameKnowledge = gameKnowledge;
	}
	
	public void initializeEvaluator()
	{
		
	}

	public void updateEvaluator()
	{
		
	}
}
