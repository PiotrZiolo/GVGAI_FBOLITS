package NextLevel;

public class GameObjectives
{
}
