package NextLevel.utils;

import NextLevel.moduleFB.moduleFBTP.MechanicsController.FBTPPathFinder;

public class Tester
{
	public void initializePathFinder()
	{
		
	}
	
	public void testPathFinder(FBTPPathFinder fbtpPathFinder)
	{
		
	}
}
