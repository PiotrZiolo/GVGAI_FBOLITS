package NextLevel.moduleTP;

import NextLevel.SituationOfInterest;
import core.game.StateObservationMulti;

public class TPSituationOfInterest extends SituationOfInterest
{
	// Real types of fields
	// protected PointOfInterest pointOfInterest;
	// protected StateObservationMulti baseState;
	// protected StateObservationMulti afterState;
	
	
	
}
