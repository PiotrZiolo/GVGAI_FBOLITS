package NextLevel;

public class State
{
}
